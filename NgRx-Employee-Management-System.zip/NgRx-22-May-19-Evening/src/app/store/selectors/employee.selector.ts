import { createSelector } from '@ngrx/store';
import { AppState } from '../app.states';
import { Employees } from '../../models/employees.model';
import { Projects } from 'src/app/models/projects.model';
import { Availability } from '../../models/employeeAvailability.model';


export class EmployeesSelector {
    public static getAllEmployees(employees): Employees[] {
        return employees.employees;
    }

    public static getEmployeeProjects(projects): Projects[] {
        // tslint:disable-next-line:no-debugger
        debugger;
        console.log('In Selector projects');
        console.log(projects);
        return projects.projects;
    }

    public static getEmployeeAvailability(availabilitys): Availability[] {
        // tslint:disable-next-line:no-debugger
        console.log('In Selector Availablity');
        console.log(availabilitys);
        return availabilitys.availabilitys;
    }
}

export const getAllEmployees = createSelector(
    (state: AppState) => state.employeeState.employees,
    EmployeesSelector.getAllEmployees,
);

export const getEmployeeProjects = createSelector(
    (state: AppState) => state.employeeState.projects,
    EmployeesSelector.getEmployeeProjects,
);

export const getEmployeeAvailability = createSelector(
    (state: AppState) => state.employeeState.availabilitys,
    EmployeesSelector.getEmployeeAvailability,
);
