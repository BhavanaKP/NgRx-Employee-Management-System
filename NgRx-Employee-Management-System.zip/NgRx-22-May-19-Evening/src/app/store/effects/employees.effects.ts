import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { tap, map, switchMap } from 'rxjs/operators';

import {
  ActionTypes,
  LoadEmployees,
  LoadEmployeesSuccess,
  ShowProjectDetails,
  ShowProjectDetailsSuccess,
  ShowAvailability,
  ShowAvailabilitySuccess
} from '../actions/employee.actions';

import { EmployeesService } from '../../services/employee.service';

@Injectable()
export class EmployeeEffects {

  constructor(
    private actions: Actions,
    private router: Router,
    private employeesService: EmployeesService
  ) { }

  @Effect()
  LoadEmployees: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.LOAD_EMPLOYEES),
    map((action: LoadEmployees) => action.payload),
    switchMap((payload) => {
      return this.employeesService.getEmployees().pipe(
        map((employee) => {
          return new LoadEmployeesSuccess({ employees: employee });
        }));
    })
  );

  @Effect({ dispatch: false })
  LoadEmployeesSuccess: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.LOAD_EMPLOYEES_SUCCESS),
    tap((employee) => {
      console.log(employee);
    })
  );

  @Effect()
  ShowProjectDetails: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.SHOW_PROJECT_DETAILS),
    map((action: ShowProjectDetails) => action.payload),
    switchMap((payload) => {
      return this.employeesService.getProjectDetails(payload).pipe(
        map((project) => {

          console.log(project);

          return new ShowProjectDetailsSuccess({ projects: project });
        }));
    })
  );

  @Effect({ dispatch: false })
  ShowProjectDetailsSuccess: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.SHOW_PROJECT_DETAILS_SUCCESS),
    tap((project) => {
      console.log('project');
    })
  );

  @Effect()
  ShowAvailability: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.SHOW_AVAILABILITY),
    map((action: ShowAvailability) => action.payload),
    switchMap((payload) => {
      return this.employeesService.getEmployeeAvailability(payload).pipe(
        map((availablity) => {
          console.log('XXXXXXXXX');
          console.log(availablity);

          return new ShowAvailabilitySuccess({ availablitys: availablity });
        }));
    })
  );

  @Effect({ dispatch: false })
  ShowAvailabilitySuccess: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.SHOW_AVAILABILITY_SUCCESS),
    tap((availablity) => {
      console.log('ShowAvalablity Effect Sucess');
      console.log(availablity);
    })
  );

}


