import * as auth from './reducers/auth.reducers';
import * as employee from './reducers/employee.reducers';
import {State} from './state';

import { createFeatureSelector } from '@ngrx/store';


export interface AppState {
  authState: State;
  employeeState: State;
}

export const reducers = {
  auth: auth.reducer,
  employeeState: employee.reducer,
};

export const selectAuthState = createFeatureSelector<AppState>('auth');
