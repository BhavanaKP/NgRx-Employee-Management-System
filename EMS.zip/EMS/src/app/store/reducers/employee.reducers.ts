import { ActionTypes, Employees } from '../actions/employee.actions';
import { State } from '../state';

// export interface State {
//   // is a user authenticated?
//   isAuthenticated: boolean;
//   // if authenticated, there should be a user object
//   user: User | null;
//   // error message
//   errorMessage: string | null;
//   // employees
//   employees:any[];
//   projects: [],
//   availabilitys: [],
// }


export const initialState: State = {
  isAuthenticated: false,
  user: null,
  errorMessage: null,
  employees: [],
  projects: [],
  availabilityzs: [],
  leaves: [],
};

export function reducer(state = initialState, action: Employees): State {
  switch (action.type) {
    case ActionTypes.LOAD_EMPLOYEES_SUCCESS: {
      return {
        ...state,
        employees: action.payload
      };
    }
    case ActionTypes.SHOW_PROJECT_DETAILS_SUCCESS: {
      console.log('In PROJECT Reducer');
      console.log(action.payload);
      console.log('-------------');
      return {
        ...state,
        projects: action.payload
      };
    }
    case ActionTypes.SHOW_LEAVES_SUCCESS: {
      console.log('In Leaves Reducer');
      console.log(action.payload);
      console.log('-------------');
      return {
        ...state,
        leaves: action.payload
      };
    }
    case ActionTypes.SHOW_AVAILABILITYZ_SUCCESS: {
      console.log('In AvailabilityZ Reducer');
      console.log(action.payload);
      console.log('-------------');
      return {
        ...state,
        availabilityzs: action.payload
      };
    }
    default:
      return state;
  }
}
