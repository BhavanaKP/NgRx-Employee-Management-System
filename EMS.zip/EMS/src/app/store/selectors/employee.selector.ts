import { createSelector } from '@ngrx/store';
import { AppState } from '../app.states';
import { Employees } from '../../models/employees.model';
import { Projects } from 'src/app/models/projects.model';
import { Leaves } from '../../models/leaves.model';
import { Availabilityz } from '../../models/Availability.model';



export class EmployeesSelector {
    public static getAllEmployees(employees): Employees[] {
        return employees.employees;
    }

    public static getEmployeeProjects(projects): Projects[] {
        console.log('IN Project SELECToR');
        console.log(projects);
        return projects.projects;
    }

    public static getLeaves(leaves): Leaves[] {
        console.log('IN Leaves SELECToR');
        console.log(leaves);
        return leaves.leaves;
    }

    public static getAvailabilityz(availabilityzs): Availabilityz[] {
        console.log('IN Availabilityz SELECToR');
        console.log(availabilityzs);
        return availabilityzs.availabilityzs;
    }
}

export const getAllEmployees = createSelector(
    (state: AppState) => state.employeeState.employees,
    EmployeesSelector.getAllEmployees,
);

export const getEmployeeProjects = createSelector(
    (state: AppState) => state.employeeState.projects,
    EmployeesSelector.getEmployeeProjects,
);

export const getLeaves = createSelector(
    (state: AppState) => state.employeeState.leaves,
    EmployeesSelector.getLeaves,
);

export const getAvailabilityz = createSelector(
    (state: AppState) => state.employeeState.availabilityzs,
    EmployeesSelector.getAvailabilityz,
)

