import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { tap, map, switchMap } from 'rxjs/operators';

import {
  ActionTypes,
  LoadEmployees,
  LoadEmployeesSuccess,
  ShowProjectDetails,
  ShowProjectDetailsSuccess,
  ShowLeaves,
  ShowLeavesSuccess,
  ShowAvailabilityz,
  ShowAvailabilityzSuccess
} from '../actions/employee.actions';

import { EmployeesService } from '../../services/employee.service';

@Injectable()
export class EmployeeEffects {

  constructor(
    private actions: Actions,
    private router: Router,
    private employeesService: EmployeesService
  ) { }

  @Effect()
  LoadEmployees: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.LOAD_EMPLOYEES),
    map((action: LoadEmployees) => action.payload),
    switchMap((payload) => {
      return this.employeesService.getEmployees().pipe(
        map((employee) => {
          return new LoadEmployeesSuccess({ employees: employee });
        }));
    })
  );

  @Effect({ dispatch: false })
  LoadEmployeesSuccess: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.LOAD_EMPLOYEES_SUCCESS),
    tap((employee) => {
      console.log(employee);
    })
  );

  @Effect()
  ShowProjectDetails: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.SHOW_PROJECT_DETAILS),
    map((action: ShowProjectDetails) => action.payload),
    switchMap((payload) => {
      return this.employeesService.getProjectDetails(payload).pipe(
        map((project) => {

          console.log(project);

          return new ShowProjectDetailsSuccess({ projects: project });
        }));
    })
  );

  @Effect({ dispatch: false })
  ShowProjectDetailsSuccess: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.SHOW_PROJECT_DETAILS_SUCCESS),
    tap((project) => {
      console.log('project');
    })
  );

  @Effect()
  ShowLeaves: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.SHOW_LEAVES),
    map((action: ShowLeaves) => action.payload),
    switchMap((payload) => {
      return this.employeesService.getLeaves(payload).pipe(
        map((leave) => {

          console.log(leave);

          return new ShowLeavesSuccess({ leaves: leave });
        }));
    })
  );

  @Effect({ dispatch: false })
  ShowLeavesSuccess: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.SHOW_LEAVES_SUCCESS),
    tap((leave) => {
    })
  );

  @Effect()
  ShowAvailabilityz: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.SHOW_AVAILABILITYZ),
    map((action: ShowAvailabilityz) => action.payload),
    switchMap((payload) => {
      return this.employeesService.getAvailabilityz(payload).pipe(
        map((availabilityz) => {
          return new ShowAvailabilityzSuccess({ availabilityzs: availabilityz });
        }));
    })
  );

  @Effect({ dispatch: false })
  ShowAvailabilityzSuccess: Observable<any> = this.actions.pipe(
    ofType(ActionTypes.SHOW_AVAILABILITYZ_SUCCESS),
    tap((availabilityz) => {
    })
  );

}
