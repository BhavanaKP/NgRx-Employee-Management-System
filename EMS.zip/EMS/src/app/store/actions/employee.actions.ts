import { Action } from '@ngrx/store';


export enum ActionTypes {
  LOAD_EMPLOYEES = 'Get All Employees',
  LOAD_EMPLOYEES_SUCCESS = 'Get Employees Success',
  SHOW_PROJECT_DETAILS = 'Show Project Details',
  SHOW_PROJECT_DETAILS_SUCCESS = 'Show Project Details Success',
  SHOW_LEAVES = 'Show Leaves',
  SHOW_LEAVES_SUCCESS = 'Show Leaves Success',
  SHOW_AVAILABILITYZ = 'Show AvailabilityZ',
  SHOW_AVAILABILITYZ_SUCCESS = 'Show AvailabilityZ Success',
}

export class LoadEmployees implements Action {
  readonly type = ActionTypes.LOAD_EMPLOYEES;
  constructor(public payload: any) { }
}

export class LoadEmployeesSuccess implements Action {
  readonly type = ActionTypes.LOAD_EMPLOYEES_SUCCESS;
  constructor(public payload: any) { }
}

export class ShowProjectDetails implements Action {
  readonly type = ActionTypes.SHOW_PROJECT_DETAILS;
  constructor(public payload: any) { }
}

export class ShowProjectDetailsSuccess implements Action {
  readonly type = ActionTypes.SHOW_PROJECT_DETAILS_SUCCESS;
  constructor(public payload: any) { }
}

export class ShowLeaves implements Action {
  readonly type = ActionTypes.SHOW_LEAVES;
  constructor(public payload:any) { }
}

export class ShowLeavesSuccess implements Action {
  readonly type = ActionTypes.SHOW_LEAVES_SUCCESS;
  constructor(public payload:any) { }
}

export class ShowAvailabilityz implements Action {
  readonly type = ActionTypes.SHOW_AVAILABILITYZ;
  constructor(public payload:any) { }
}

export class ShowAvailabilityzSuccess implements Action {
  readonly type = ActionTypes.SHOW_AVAILABILITYZ_SUCCESS;
  constructor(public payload:any) { }
}

export type Employees =
  | LoadEmployees
  | LoadEmployeesSuccess
  | ShowProjectDetails
  | ShowProjectDetailsSuccess
  | ShowLeaves
  | ShowLeavesSuccess
  | ShowAvailabilityz
  | ShowAvailabilityzSuccess
  
