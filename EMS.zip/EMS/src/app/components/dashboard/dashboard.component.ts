import * as Highcharts from 'highcharts';
import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';

import { AppState, selectAuthState } from '../../store/app.states';
import { LogOut } from '../../store/actions/auth.actions';
import { Employees } from '../../models/employees.model';
import { Projects } from '../../models/projects.model';
import { Leaves } from '../../models/leaves.model';
import { Availabilityz } from '../../models/availability.model';

import { LoadEmployees, ShowProjectDetails, ShowAvailabilityz, ShowLeaves } from '../../store/actions/employee.actions';
import { getAllEmployees, getEmployeeProjects, getAvailabilityz, getLeaves } from '../../store/selectors/employee.selector';



declare var require: any;
const Boost = require('highcharts/modules/boost');
const noData = require('highcharts/modules/no-data-to-display');
const More = require('highcharts/highcharts-more');

Boost(Highcharts);
noData(Highcharts);
More(Highcharts);
noData(Highcharts);

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {


  public getState: Observable<any>;
  public isAuthenticated = false;
  public user: any = null;
  public errorMessage: string = null;
  public employees: Employees[] = [];
  public projects: Projects[] = [];
  public leaves: Leaves[] = [];
  public availabilityz: Availabilityz[] = [];
  public pieSliceData: any[] = [];
  public donutSliceData: any[] = [];

  public employeeName: string;

  public donutChartOptions: any = {
    // Build the chart
    chart: {
      plotBackgroundColor: null,
      plotBorderWidth: null,
      plotShadow: false,
      type: 'pie'
    },
    title: {
      text: 'Employee Leaves'
    },
    tooltip: {
      pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
      pie: {
        dataLabels: {
          enabled: true,
          distance: -50,
          style: {
            fontWeight: 'bold',
            color: 'white'
          }
        },
        startAngle: -90,
        endAngle: 90,
        center: ['50%', '75%'],
        size: '110%'
      }
    },
    series: [{
      name: 'Bo Lais',
      colorByPoint: true,
      data: this.pieSliceData,
    }]
  };

  public pieChartOptions: any = {
    // Build the chart
    chart: {
      plotBackgroundColor: null,
      plotBorderWidth: null,
      plotShadow: false,
      type: 'pie'
    },
    title: {
      text: 'Employee Avalibilty'
    },
    tooltip: {
      pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
      pie: {
        allowPointSelect: true,
        cursor: 'pointer',
        dataLabels: {
          enabled: true,
          format: '<b>{point.name}</b>: {point.percentage:.1f} %'
        }
      }
    },
    series: [{
      name: 'Bo Lais',
      colorByPoint: true,
      data: this.pieSliceData,
    }]
  };




  constructor(
    private store: Store<AppState>
  ) {
    this.getState = this.store.select(selectAuthState);
  }

  ngOnInit() {

    this.getState.subscribe((state) => {
      this.isAuthenticated = state.isAuthenticated;
      this.user = state.user;
      this.errorMessage = state.errorMessage;
    });

    if (this.isAuthenticated) {
      const payload = {
        employees: this.employees,
      };

      this.store.dispatch(new LoadEmployees(payload));

      this.store.select(getAllEmployees).subscribe((employee: Employees[]) => {
        this.employees = employee;

        if (this.employees) {
          this.employees = employee;
        }
      });
    }

  }

  public searchEmployee(employeeName) {
    let searchedEmployee: any[];
    const realEmployees = this.employees;

    searchedEmployee = this.employees.filter((employee) => {
      if (employee.name === employeeName) {
        return employee;
      }
    });

    if (searchedEmployee && searchedEmployee.length > 0) {
      this.employees = searchedEmployee;
    } else {
      this.employees = realEmployees;
    }
  }

  public onClickShowDetails(employeeId) {
    const payload = {
      employeeId,
    };

    this.store.dispatch(new ShowProjectDetails(payload.employeeId));
    this.store.select(getEmployeeProjects).subscribe((projects: Projects[]) => {
      this.projects = projects;
    });

    //Employee Leaves
    this.store.dispatch(new ShowLeaves(payload.employeeId));
    this.store.select(getLeaves).subscribe((leaves: Leaves[]) => {
      this.leaves = leaves;

      if (this.leaves) {
        for (const item of this.leaves) {
          this.donutSliceData.push([item.month, item.leaves]);
        }

        if (this.donutSliceData.length > 0) {
          Highcharts.chart('containerLeaves', this.donutChartOptions);

        }
      }
    });

    //Employee Availability
    this.store.dispatch(new ShowAvailabilityz(payload.employeeId));
    this.store.select(getAvailabilityz).subscribe((availabilityz: Availabilityz[]) => {
      this.availabilityz = availabilityz;

      if (this.availabilityz) {

        for (const item of this.availabilityz) {
          this.pieSliceData.push([item.month, item.percentage]);
        }

        if (this.pieSliceData.length > 0) {
          Highcharts.chart('containerAvailablity', this.pieChartOptions);
        }

      }

    });


  }

  logOut(): void {
    // tslint:disable-next-line:new-parens
    this.store.dispatch(new LogOut);
  }

}
