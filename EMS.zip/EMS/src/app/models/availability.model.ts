export class Availabilityz {
    employeeId?: string;
    employeeName?: string;
    month?: string;
    percentage?: number;
    leaves?: number;
}
