export class Leaves {
    employeeId?: string;
    employeeName?: string;
    month?: string;
    percentage?: number;
    leaves?: number;
  }
